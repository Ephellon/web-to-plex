(() => {
  var __defProp = Object.defineProperty;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

  // src/background/common.js
  var REPLIED = /* @__PURE__ */ Symbol("replied");
  var QUIET = { error: /* @__PURE__ */ __name((m) => m, "error"), info: /* @__PURE__ */ __name((m) => m, "info"), log: /* @__PURE__ */ __name((m) => m, "log"), warn: /* @__PURE__ */ __name((m) => m, "warn"), group: /* @__PURE__ */ __name((m) => m, "group"), groupEnd: /* @__PURE__ */ __name((m) => m, "groupEnd") };
  var terminal = QUIET;
  function Terminal() {
    return terminal;
  }
  __name(Terminal, "Terminal");
  async function RefreshTerminal() {
    const { DeveloperMode } = await GetOptions();
    terminal = DeveloperMode ? console : QUIET;
    terminal.warn(`BACKGROUND_DEVELOPER: ${DeveloperMode}`);
    return !!DeveloperMode;
  }
  __name(RefreshTerminal, "RefreshTerminal");
  function GetOptions() {
    return new Promise((resolve) => {
      const area = chrome.storage.sync ?? chrome.storage.local;
      area.get(null, (options) => {
        if (chrome.runtime.lastError)
          chrome.storage.local.get(null, resolve);
        else
          resolve(options ?? {});
      });
    });
  }
  __name(GetOptions, "GetOptions");
  function RequestHeaders(authorization) {
    const headers = { Accept: "application/json" };
    if (!authorization)
      return headers;
    return {
      Authorization: `Basic ${btoa(`${authorization.username}:${authorization.password}`)}`,
      ...headers
    };
  }
  __name(RequestHeaders, "RequestHeaders");
  function formify(data) {
    const body = [];
    for (const key in data)
      body.push(`${key}=${data[key]}`);
    return body.join("&");
  }
  __name(formify, "formify");

  // src/background/defaults.js
  var BUILTINS = [
    "allocine",
    "amazon",
    "couchpotato",
    "fandango",
    "flickmetrix",
    "google",
    "googleplay",
    "hulu",
    "imdb",
    "justwatch",
    "letterboxd",
    "moviemeter",
    "movieo",
    "netflix",
    "plex",
    "rottentomatoes",
    "shanaproject",
    "showrss",
    "tmdb",
    "tvmaze",
    "tvdb",
    "trakt",
    "vrv",
    "verizon",
    "vudu",
    "vumoo",
    "youtube",
    "itunes",
    "gostream",
    "tubi",
    "webtoplex"
  ];
  var DOMAINS = [
    "allocine.fr",
    "amazon.com",
    "couchpotato.life",
    "fandango.com",
    "flickmetrix.com",
    "google.com",
    "play.google.com",
    "gostream.site",
    "hulu.com",
    "imdb.com",
    "itunes.apple.com",
    "justwatch.com",
    "letterboxd.com",
    "moviemeter.nl",
    "movieo.me",
    "netflix.com",
    "app.plex.tv",
    "rottentomatoes.com",
    "shanaproject.com",
    "showrss.info",
    "themoviedb.org",
    "trakt.tv",
    "app.trakt.tv",
    "tubitv.com",
    "tvmaze.com",
    "thetvdb.com",
    "verizon.com",
    "vrv.co",
    "vudu.com",
    "vumoo.to",
    "webtoplex.github.io",
    "ephellon.github.io",
    "youtube.com",
    "foxsearchlight.com",
    "freemoviescinema.com",
    "freeform.go.com",
    "indomovietv.club",
    "indomovietv.org",
    "indomovietv.net",
    "kitsu.io",
    "metacritic.com",
    "myanimelist.net",
    "myshows.me",
    "redbox.com",
    "snagfilms.com",
    "toloka.to"
  ];
  var DEFAULT_OPTIONS = {
    __caught: '{"imdb":[],"tmdb":[],"tvdb":[]}',
    __theme: "{}",
    __domains: DOMAINS.join(","),
    ...Object.fromEntries(BUILTINS.map((name) => [`builtin_${name}`, true])),
    UseOmbi: true,
    UseLoose: true,
    UseLooseScore: "40",
    AutoGrabLimit: "30",
    DeveloperMode: true
  };
  function MissingDefaults(stored = {}) {
    const missing = {};
    for (const [key, value] of Object.entries(DEFAULT_OPTIONS))
      if (!(key in stored))
        missing[key] = value;
    if (!("IGNORE_PLEX" in stored) && !stored.plexToken)
      missing.IGNORE_PLEX = true;
    return missing;
  }
  __name(MissingDefaults, "MissingDefaults");
  async function SeedDefaults({ reason } = {}) {
    if (reason != "install" && reason != "update")
      return {};
    const missing = MissingDefaults(await GetOptions());
    if (Object.keys(missing).length)
      await (chrome.storage.sync ?? chrome.storage.local).set(missing).catch(() => chrome.storage.local.set(missing));
    return missing;
  }
  __name(SeedDefaults, "SeedDefaults");

  // src/background/badge.js
  function SetBadge(text, known) {
    const action = chrome.action ?? chrome.browserAction;
    action.setBadgeText({
      text
    });
    action.setBadgeBackgroundColor({
      color: known ? "#f45a26" : "#666666"
    });
  }
  __name(SetBadge, "SetBadge");

  // src/background/menus.js
  var EXTERNAL = "external";
  var STATUS_QUEUE = Promise.resolve();
  var Serial = /* @__PURE__ */ __name((task) => STATUS_QUEUE = STATUS_QUEUE.then(task, task), "Serial");
  function CreateMenus() {
    const parent = chrome.contextMenus.create({
      id: "W2P",
      title: "Web to Plex"
    });
    chrome.contextMenus.create({
      id: "W2P-DL",
      title: "Nothing to Save"
    });
    for (const item of ["IM", "TM", "TV"])
      chrome.contextMenus.create({
        id: "W2P-" + item,
        parentId: parent,
        title: `Using ${item}Db`,
        type: "checkbox",
        checked: true
        // implement a way to use the checkboxes?
      });
    chrome.contextMenus.create({
      id: "W2P-XX",
      parentId: parent,
      title: "Using best guess",
      type: "checkbox",
      checked: true
      // implement a way to use the checkboxes?
    });
  }
  __name(CreateMenus, "CreateMenus");
  async function ReadExternal() {
    return (await chrome.storage.session.get(EXTERNAL))[EXTERNAL] ?? {};
  }
  __name(ReadExternal, "ReadExternal");
  function ParseItem(request = {}) {
    const item = request.options || request, ID_PROVIDER = ((i) => {
      for (const p in i)
        if (/^TV(Db)?/i.test(p) && i[p])
          return "TVDb";
        else if (/^TM(Db)?/i.test(p) && i[p])
          return "TMDb";
      return "IMDb";
    })(item), ITEM_ID = ((i, I) => {
      for (const p in i)
        if (RegExp("^" + I, "i").test(p))
          return i[p];
    })(item, ID_PROVIDER);
    let ITEM_TYPE = item.type;
    if (/movie|film|cinema|theat[re]{2}/i.test(ITEM_TYPE))
      ITEM_TYPE = "movie";
    else if (/tv|show|series|episode/i.test(ITEM_TYPE))
      ITEM_TYPE = "show";
    return {
      item,
      ITEM_TITLE: item.title,
      ITEM_YEAR: item.year,
      ITEM_TYPE,
      ID_PROVIDER,
      ITEM_URL: item.href || "",
      FILE_TYPE: item.tail || "mp4",
      FILE_PATH: item.path || "",
      ITEM_ID
    };
  }
  __name(ParseItem, "ParseItem");
  function ChangeStatus(details) {
    return Serial(() => SetStatus(details));
  }
  __name(ChangeStatus, "ChangeStatus");
  async function SetStatus({ ITEM_ID, ITEM_TITLE, ITEM_TYPE, ID_PROVIDER, ITEM_YEAR, ITEM_URL = "", FILE_TYPE = "", FILE_PATH, TAB_ID }) {
    const YEAR = (/* @__PURE__ */ new Date()).getFullYear(), FILE_TITLE = ITEM_TITLE.replace(/-/g, " ").replace(/[\s:]{2,}/g, " - ").replace(/[^\w\s\-']+/g, ""), SEARCH_TITLE = ITEM_TITLE.replace(/[-\s]+/g, "-").replace(/\s*&\s*/g, " and ").replace(/[^\w\-'*#]+/g, ""), SEARCH_PROVIDER = ITEM_TYPE == "show" ? "GG" : /^im/i.test(ID_PROVIDER) ? "VO" : /^tm/i.test(ID_PROVIDER) ? "GX" : "GG";
    ITEM_ID = (ITEM_ID && !/^tt$/i.test(ITEM_ID) ? ITEM_ID : "") + "";
    ITEM_ID = ITEM_ID.replace(/^.*\b(tt\d+)\b.*$/, "$1").replace(/^.*\bid=(\d+)\b.*$/, "$1").replace(/^.*(?:movie|tv|(?:tv-?)?(?:shows?|series|episodes?))\/(\d+).*$/, "$1");
    const external = { ...await ReadExternal(), ID_PROVIDER, ITEM_ID, ITEM_TITLE, ITEM_YEAR, ITEM_URL, ITEM_TYPE, SEARCH_PROVIDER, SEARCH_TITLE, FILE_PATH, FILE_TITLE, FILE_TYPE, TAB_ID };
    await chrome.storage.session.set({ [EXTERNAL]: external });
    SetBadge(ID_PROVIDER, !!ITEM_ID);
    chrome.contextMenus.update("W2P", {
      title: `Find "${ITEM_TITLE} (${ITEM_YEAR || YEAR})"`
    });
    for (let database of ["IM", "TM", "TV"])
      chrome.contextMenus.update("W2P-" + database, {
        title: ID_PROVIDER == (database += "Db") && ITEM_ID ? `Open in ${database} (${(+ITEM_ID ? "#" : "") + ITEM_ID})` : `Find in ${database}`,
        checked: false
      });
    chrome.contextMenus.update("W2P-XX", {
      title: `Find on ${SEARCH_PROVIDER == "VO" ? "Vumoo" : SEARCH_PROVIDER == "GX" ? "GoStream" : "Google"}`,
      checked: false
    });
    return external;
  }
  __name(SetStatus, "SetStatus");
  function ForgetStatus(tabId) {
    return Serial(() => Forget(tabId));
  }
  __name(ForgetStatus, "ForgetStatus");
  async function Forget(tabId) {
    const { TAB_ID } = await ReadExternal();
    if (TAB_ID == null || TAB_ID != tabId)
      return;
    await chrome.storage.session.remove(EXTERNAL);
    SetBadge("", false);
    chrome.contextMenus.update("W2P", { title: "Web to Plex" });
    chrome.contextMenus.update("W2P-DL", { title: "Nothing to Save" });
    for (const database of ["IM", "TM", "TV"])
      chrome.contextMenus.update("W2P-" + database, { title: `Using ${database}Db`, checked: true });
    chrome.contextMenus.update("W2P-XX", { title: "Using best guess", checked: true });
  }
  __name(Forget, "Forget");
  function SwitchStatus(tabId) {
    return Serial(async () => {
      const { TAB_ID } = await ReadExternal();
      if (TAB_ID != null && TAB_ID != tabId)
        await Forget(TAB_ID);
    });
  }
  __name(SwitchStatus, "SwitchStatus");
  async function OnMenuClicked(item) {
    if (!/^W2P/i.test(item.menuItemId))
      return;
    const external = await ReadExternal();
    let url = "", dnl = false;
    const db = item.menuItemId.slice(-2).toLowerCase(), pv = (external.ID_PROVIDER || "").slice(0, 2).toLowerCase(), qu = external.ITEM_ID, tl = external.SEARCH_TITLE, yr = external.ITEM_YEAR, tt = external.ITEM_TITLE, lt = external.FILE_TITLE, ft = external.FILE_TYPE, fp = external.FILE_PATH, p = /* @__PURE__ */ __name((s, r = "+") => s.replace(/-/g, r), "p");
    switch (db) {
      case "im":
        {
          url = qu && pv == "im" ? `imdb.com/title/${qu}/` : `imdb.com/find?ref_=nv_sr_fn&s=all&q=${encodeURIComponent(tt)}`;
        }
        break;
      case "tm":
        {
          url = qu && pv == "tm" ? `themoviedb.org/${external.ITEM_TYPE == "show" ? "tv" : "movie"}/${qu}` : `themoviedb.org/search?query=${encodeURIComponent(tt)}`;
        }
        break;
      case "tv":
        {
          url = qu && pv == "tv" ? `thetvdb.com/series/${tl}#${qu}` : `thetvdb.com/search?q=${p(encodeURIComponent(tl))}`;
        }
        break;
      case "xx":
        {
          url = external.SEARCH_PROVIDER == "VO" ? `google.com/search?q=${p(encodeURIComponent(tl))}+site:vumoo.to` : external.SEARCH_PROVIDER == "GX" ? `gostream.site?s=${p(encodeURIComponent(tl))}` : `google.com/search?q="${encodeURIComponent(p(tl, " "))} ${yr}"+${pv}db`;
        }
        break;
      case "dl":
        {
          dnl = true;
          url = external.ITEM_URL;
        }
        break;
      default: {
        return;
      }
    }
    if (!dnl)
      chrome.tabs.create({ url: `https://${url}` });
    else
      chrome.downloads.download({
        url,
        filename: `${fp}${lt} (${yr}).${ft}`,
        saveAs: true
      }, (id) => {
        if (id == null)
          chrome.downloads.download({
            url,
            saveAs: true
          });
      });
  }
  __name(OnMenuClicked, "OnMenuClicked");
  function SaveAs({ ITEM_TITLE, ITEM_YEAR, FILE_TYPE }) {
    chrome.contextMenus.update("W2P-DL", {
      title: `Save as "${ITEM_TITLE} (${ITEM_YEAR})" (${FILE_TYPE})`
    });
  }
  __name(SaveAs, "SaveAs");
  function DownloadFile({ item, ITEM_TITLE, ITEM_YEAR, FILE_TYPE }) {
    const FILE_TITLE = ITEM_TITLE.replace(/-/g, " ").replace(/[\s:]{2,}/g, " - ").replace(/[^\w\s\-']+/g, "");
    chrome.downloads.download({
      url: item.href,
      filename: `${FILE_TITLE} (${ITEM_YEAR}).${FILE_TYPE}`,
      saveAs: true
    }, (id) => {
      if (id == null)
        chrome.downloads.download({
          url: item.href,
          filename: `${FILE_TITLE} (${ITEM_YEAR})`,
          saveAs: true
        });
    });
  }
  __name(DownloadFile, "DownloadFile");

  // src/background/services/plex.js
  function PromiseRace(promises) {
    if (!promises.length) {
      return Promise.reject("Cannot start a race without promises!");
    }
    const Promises = promises.map(
      (promise, index) => promise.catch(() => {
        throw index;
      })
    );
    return Promise.race(Promises).catch((index) => {
      const promise = promises.splice(index, 1)[0];
      promise.catch((error) => Terminal().log(`Plex request #${index} failed:`, error));
      return PromiseRace(promises);
    });
  }
  __name(PromiseRace, "PromiseRace");
  function $Search_Plex(connection, headers, options) {
    let type = options.type || "movie", url = `${connection.uri}/hubs/search`, field = options.field || "title";
    if (!options.title)
      return {};
    if (/movie|film|cinema|theat[re]{2}/i.test(type))
      type = "movie";
    else if (/tv|show|series|episode/i.test(type))
      type = "show";
    const title = encodeURIComponent(options.title.replace(/\s+/g, " ")), finalURL = `${url}?query=${field}:${title}`;
    return fetch(finalURL, { headers }).then((response) => response.json()).then((data) => {
      const Hub = data.MediaContainer.Hub.find((hub) => hub.type === type);
      if (!Hub || !Hub.Metadata)
        return { found: false };
      const items = Hub.Metadata.filter(
        (meta) => meta.Directory || meta.Genre || meta.Country || meta.Role || meta.Writer
      ), strip = /* @__PURE__ */ __name((string) => string.replace(/\W+/g, "").toLowerCase(), "strip");
      let media = items.find((meta) => (meta.year == +options.year || meta.year == +options.year + 1) && strip(meta.title) == strip(options.title)), key = null;
      if (!media && options.IMDbID)
        media = items.find((meta) => new RegExp("imdb://" + options.IMDbID, "i").test(meta.guid));
      key = media ? media.key.replace("/children", "") : key;
      return {
        found: !!media,
        key
      };
    }).catch((error) => {
      throw error;
    });
  }
  __name($Search_Plex, "$Search_Plex");
  async function Search_Plex(request, sendResponse) {
    let { options, serverConfig } = request, headers = {
      "X-Plex-Token": serverConfig.token,
      "Accept": "application/json"
    };
    const requests = serverConfig.connections.map(
      (connection) => $Search_Plex(connection, headers, options)
    );
    try {
      const result = await PromiseRace(requests);
      sendResponse(result);
    } catch (error) {
      sendResponse({ error: String(error), location: "@0B: Search_Plex" });
    }
  }
  __name(Search_Plex, "Search_Plex");

  // src/background/services/couchpotato.js
  function Query_CouchPotato(request, sendResponse) {
    fetch(`${request.url}?id=${request.imdbId}`, {
      headers: RequestHeaders(request.basicAuth)
    }).then((response) => response.json()).then((json) => {
      const { success } = json;
      sendResponse({ success, status: success ? json.media.status : null });
    }).catch((error) => {
      sendResponse({ error: String(error), location: "@0B: Query_CouchPotato" });
    });
  }
  __name(Query_CouchPotato, "Query_CouchPotato");
  function Push_CouchPotato(request, sendResponse) {
    const headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, query = `identifier=${request.imdbId}`, debug = { headers, query, request };
    fetch(debug.url = `${request.url}?${query}`, {
      method: "POST",
      // body: JSON.stringify(body),
      headers
    }).then((response) => response.json()).catch((error) => {
      sendResponse({ error: "Movie not found", location: "@0B: Push_CouchPotato => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((response) => {
      sendResponse({ success: response.success });
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: '@0B: Push_CouchPotato => fetch("${ request.url }", { headers }).catch(error => { sendResponse })',
        debug
      });
    });
  }
  __name(Push_CouchPotato, "Push_CouchPotato");
  function Charge_CouchPotato(request, sendResponse) {
    fetch(request.url, {
      headers: RequestHeaders(request.basicAuth)
    }).then((response) => response.json()).then((json) => sendResponse(json)).catch((error) => sendResponse({ error: String(error), location: "@0B: Charge_CouchPotato" }));
  }
  __name(Charge_CouchPotato, "Charge_CouchPotato");

  // src/background/services/watcher.js
  function Push_Watcher(request, sendResponse) {
    let headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, id = /^(tt)?$/.test(request.imdbId) ? request.tmdbId : request.imdbId, query = /^tt\d+$/i.test(id) ? "imdbid" : /^\d+$/.test(id) ? "tmdbid" : (id = encodeURI(`${request.title} ${request.year}`), "term"), debug = { headers, query, request };
    fetch(debug.url = `${request.url}?apikey=${request.token}&mode=addmovie&${query}=${id}`, { headers }).then((response) => response.json()).catch((error) => {
      sendResponse({ error: "Movie not found", location: "@0B: Push_Watcher => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((response) => {
      if (response.response + "" == "true")
        return sendResponse({
          success: `Added to Watcher (${request.StoragePath})`
        });
      throw new Error(response.error);
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_Watcher => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_Watcher, "Push_Watcher");

  // src/background/services/radarr.js
  function Push_Radarr(request, sendResponse) {
    let headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, id = /^(tt)?$/.test(request.imdbId) ? request.tmdbId : request.imdbId, query = /^tt\d+$/i.test(id) ? "imdb?imdbid" : /^\d+$/.test(id) ? "tmdb?tmdbid" : (id = encodeURI(`${request.title} ${request.year}`), "term"), debug = { headers, query, request };
    let base = request.url;
    const bases = [request.url.replace(/\/api\/movie\/?$/, "/api/v3/movie/"), request.url].filter((url, index, all) => all.indexOf(url) == index);
    (async () => {
      let response;
      for (base of bases) {
        response = await fetch(debug.url = `${base}lookup/${query}=${id}&apikey=${request.token}`);
        if (response.ok)
          break;
      }
      return response;
    })().then((response) => response.json()).catch((error) => {
      sendResponse({ error: "Movie not found", location: "@0B: Push_Radarr => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((data) => {
      let body, props = {
        monitored: true,
        minimumAvailability: "preDB",
        qualityProfileId: request.QualityID,
        rootFolderPath: request.StoragePath,
        addOptions: {
          searchForMovie: true
        }
      };
      if (!data || !data.length && !data.title) {
        throw new Error("Movie not found");
      } else if (data.length) {
        body = {
          ...data[0],
          ...props
        };
      } else if (data.title) {
        body = {
          ...data,
          ...props
        };
      }
      Terminal().group("Generated URL");
      Terminal().log("URL", request.url);
      Terminal().log("Head", headers);
      Terminal().log("Body", body);
      Terminal().groupEnd();
      return debug.body = body;
    }).then((body) => {
      return fetch(`${base}?apikey=${request.token}`, debug.requestHeaders = {
        method: "POST",
        // mode: cors(request.url),
        body: JSON.stringify(body),
        headers
      });
    }).then((response) => response.text()).then((data) => {
      debug.data = data = JSON.parse(data || `{"path":"${request.StoragePath.replace(/\\/g, "\\\\")}${request.title} (${request.year})"}`);
      if (data && data[0] && data[0].errorMessage) {
        sendResponse({
          error: data[0].errorMessage,
          location: `@0B: Push_Radarr => fetch("${request.url}", { headers }).then(data => { if })`,
          debug
        });
      } else if (data && data.path) {
        sendResponse({
          success: "Added to " + data.path
        });
      } else {
        sendResponse({
          error: "Unknown error",
          location: `@0B: Push_Radarr => fetch("${request.url}", { headers }).then(data => { else })`,
          debug
        });
      }
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_Radarr => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_Radarr, "Push_Radarr");

  // src/background/services/sonarr.js
  function Push_Sonarr(request, sendResponse) {
    const headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, id = request.tvdbId, query = encodeURIComponent(`tvdb:${id}`), debug = { headers, query, request };
    let base = request.url;
    const bases = [request.url.replace(/\/api\/series\/?$/, "/api/v3/series/"), request.url].filter((url, index, all) => all.indexOf(url) == index);
    (async () => {
      let response;
      for (base of bases) {
        response = await fetch(debug.url = `${base}lookup?apikey=${request.token}&term=${query}`);
        if (response.ok)
          break;
      }
      return response;
    })().then((response) => response.json()).catch((error) => {
      sendResponse({ error: "TV Show not found", location: "@0B: Push_Sonarr => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((data) => {
      if (!(data instanceof Array) || !data.length)
        throw new Error("TV Show not found");
      const body = {
        ...data[0],
        monitored: true,
        seasonFolder: true,
        minimumAvailability: "preDB",
        qualityProfileId: request.QualityID,
        rootFolderPath: request.StoragePath,
        addOptions: {
          searchForMissingEpisodes: true
        }
      };
      Terminal().group("Generated URL");
      Terminal().log("URL", request.url);
      Terminal().log("Head", headers);
      Terminal().log("Body", body);
      Terminal().groupEnd();
      return debug.body = body;
    }).then(async (body) => {
      if (!body.languageProfileId && /\/api\/v3\//.test(base)) {
        const profiles = await fetch(`${base.replace(/series\/?$/, "languageprofile")}?apikey=${request.token}`).then((response) => response.ok ? response.json() : null).catch(() => null);
        if (profiles instanceof Array && profiles.length)
          body.languageProfileId = profiles[0].id;
      }
      return fetch(`${base}?apikey=${request.token}`, debug.requestHeaders = {
        method: "POST",
        // mode: cors(request.url),
        body: JSON.stringify(body),
        headers
      });
    }).then((response) => response.text()).then((data) => {
      debug.data = data = JSON.parse(data || `{"path":"${request.StoragePath.replace(/\\/g, "\\\\")}${request.title} (${request.year})"}`);
      if (data && data[0] && data[0].errorMessage) {
        sendResponse({
          error: data[0].errorMessage,
          location: `@0B: Push_Sonarr => fetch("${request.url}", { headers }).then(data => { if })`,
          debug
        });
      } else if (data && data.path) {
        sendResponse({
          success: "Added to " + data.path
        });
      } else {
        sendResponse({
          error: "Unknown error",
          location: `@0B: Push_Sonarr => fetch("${request.url}", { headers }).then(data => { else })`,
          debug
        });
      }
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_Sonarr => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_Sonarr, "Push_Sonarr");

  // src/background/services/medusa.js
  function Push_Medusa(request, sendResponse) {
    const headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, id = request.tvdbId, query = request.title.replace(/\s+/g, "+"), debug = { headers, query, request };
    fetch(debug.url = `${request.root}internal/searchIndexersForShowName?api_key=${request.token}&indexerId=0&query=${query}`).then((response) => response.json()).catch((error) => {
      sendResponse({ error: "TV Show not found", location: "@0B: Push_Medusa => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((data) => {
      data = data.results;
      if (!(data instanceof Array) || !data.length)
        throw new Error("TV Show not found");
      const body = { id: { tvdb: id } };
      Terminal().group("Generated URL");
      Terminal().log("URL", request.url);
      Terminal().log("Head", headers);
      Terminal().log("Body", body);
      Terminal().groupEnd();
      return debug.body = body;
    }).then((body) => {
      return fetch(`${request.url}`, debug.requestHeaders = {
        method: "POST",
        // mode: cors(request.url),
        body: JSON.stringify(body),
        headers
      });
    }).then((response) => response.text()).then((data) => {
      const path = request.StoragePath.replace(/\\?$/, "\\");
      debug.data = data = JSON.parse(data || `{"path":"${path}${request.title} (${request.year})"}`);
      if (data && data.error) {
        sendResponse({
          error: data.error,
          location: `@0B: Push_Medusa => fetch("${request.url}", { headers }).then(data => { if })`,
          debug
        });
      } else if (data && data.id) {
        sendResponse({
          success: `Added to ${path}${request.title}(${request.year})`
        });
      } else {
        sendResponse({
          error: "Unknown error",
          location: `@0B: Push_Medusa => fetch("${request.url}", { headers }).then(data => { else })`,
          debug
        });
      }
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_Medusa => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_Medusa, "Push_Medusa");

  // src/background/services/sickbeard.js
  function Push_SickBeard(request, sendResponse) {
    const headers = {
      "Content-Type": "application/json",
      "X-Api-Key": request.token,
      ...RequestHeaders(request.basicAuth)
    }, id = request.tvdbId, query = `tvdbid=${id}`, path = `${request.StoragePath}\\${request.title}`.replace(/\\\\/g, "\\"), debug = { headers, query, request };
    fetch(debug.url = `${request.url}?cmd=sb.searchtvdb&${query}`).then((response) => response.json()).catch((error) => {
      sendResponse({ error: "TV Show not found", location: "@0B: Push_SickBeard => fetch.then.catch", silent: true });
      throw REPLIED;
    }).then((data) => {
      if (!/^success$/i.test(data.result))
        throw new Error("TV Show not found");
      data = data.data.results;
      const body = formify({
        tvdbid: id,
        initial: request.QualityID,
        location: encodeURIComponent(path),
        status: "wanted"
      });
      Terminal().group("Generated URL");
      Terminal().log("URL", request.url);
      Terminal().log("Head", headers);
      Terminal().log("Body", body);
      Terminal().groupEnd();
      return debug.body = body;
    }).then(async (body) => {
      await fetch(`${request.url}?cmd=sb.addrootdir&${body}`);
      return fetch(`${request.url}?cmd=show.${request.exists ? "addexisting" : "addnew"}&${body}`, debug.requestHeaders = {
        method: "POST",
        // mode: cors(request.url),
        // body: JSON.stringify(body),
        headers
      });
    }).then((response) => response.text()).then((results) => {
      debug.data = results = JSON.parse(results || `{"data":{},"message":"","result":""}`);
      const { data, message, result } = results;
      if (data && !/^success$/i.test(result) && message) {
        sendResponse({
          error: message,
          location: `@0B: Push_SickBeard => fetch("${request.url}", { headers }).then(results => { if })`,
          debug
        });
      } else if (data && data.path) {
        sendResponse({
          success: `Added to ${request.StoragePath}${request.title} (${request.year})`
        });
      } else {
        sendResponse({
          error: "Unknown error",
          location: `@0B: Push_SickBeard => fetch("${request.url}", { headers }).then(results => { else })`,
          debug
        });
      }
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_SickBeard => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_SickBeard, "Push_SickBeard");

  // src/background/services/ombi.js
  function Push_Ombi(request, sendResponse) {
    const headers = {
      "Content-Type": "application/json",
      "ApiKey": request.token,
      ...RequestHeaders()
    }, type = request.contentType, id = type == "movie" ? request.tmdbId : request.tvdbId, body = { [type == "movie" ? "theMovieDbId" : "tvDbId"]: id, requestAll: true, latestSeason: true, firstSeason: true }, debug = { headers, body, request };
    if (request.contentType == "movie" && (id || null) === null)
      return sendResponse({ error: "Invalid TMDbID", location: "@0B: Push_Ombi => if", silent: true });
    else if ((id || null) === null)
      return sendResponse({ error: "Invalid TVDbID", location: "@0B: Push_Ombi => else if", silent: true });
    fetch(debug.url = request.url, {
      method: "POST",
      // mode: cors(request.url),
      body: JSON.stringify(body),
      headers
    }).catch((error) => {
      sendResponse({ error: `${type} not found`, location: "@0B: Push_Ombi => fetch.then.catch", debug, silent: true });
      throw REPLIED;
    }).then((response) => response.text()).then((data) => {
      debug.data = data = JSON.parse(data);
      if (data && data.isError) {
        if (/already +been +requested/i.test(data.errorMessage))
          sendResponse({
            success: "Already requested on Ombi"
          });
        else
          sendResponse({
            error: data.errorMessage,
            location: `@0B: Push_Ombi => fetch("${request.url}", { headers }).then(data => { if })`,
            debug
          });
      } else if (data && data.path) {
        sendResponse({
          success: "Added to Ombi"
        });
      } else {
        sendResponse({
          error: "Unknown error",
          location: `@0B: Push_Ombi => fetch("${request.url}", { headers }).then(data => { else })`,
          debug
        });
      }
    }).catch((error) => {
      if (error === REPLIED)
        return;
      sendResponse({
        error: String(error),
        location: `@0B: Push_Ombi => fetch("${request.url}", { headers }).catch(error => { sendResponse })`,
        debug
      });
    });
  }
  __name(Push_Ombi, "Push_Ombi");

  // src/background/services/relay.js
  async function Service_Fetch(request, reply) {
    const urls = [].concat(request.urls ?? []).filter((url) => /^https?:\/\//i.test(url)), init = { method: request.method ?? "GET", headers: request.headers ?? {}, body: request.body, credentials: "omit" };
    let last = { error: "No http(s) URL to fetch" };
    for (const url of urls) {
      try {
        const response = await fetch(url, init), text = await response.text();
        last = { ok: response.ok, status: response.status, url, text };
        if (response.ok)
          break;
      } catch (error) {
        last = { error: String(error), url };
      }
    }
    reply(last);
  }
  __name(Service_Fetch, "Service_Fetch");

  // src/background/router.js
  var ROUTES = {
    SEARCH_PLEX: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Search_Plex(request, reply), "handle") },
    CHARGE_COUCHPOTATO: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Charge_CouchPotato(request, reply), "handle") },
    QUERY_COUCHPOTATO: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Query_CouchPotato(request, reply), "handle") },
    PUSH_COUCHPOTATO: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_CouchPotato(request, reply), "handle") },
    PUSH_RADARR: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_Radarr(request, reply), "handle") },
    PUSH_SONARR: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_Sonarr(request, reply), "handle") },
    PUSH_MEDUSA: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_Medusa(request, reply), "handle") },
    PUSH_WATCHER: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_Watcher(request, reply), "handle") },
    PUSH_OMBI: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_Ombi(request, reply), "handle") },
    PUSH_SICKBEARD: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Push_SickBeard(request, reply), "handle") },
    SERVICE_FETCH: { replies: true, handle: /* @__PURE__ */ __name((request, reply) => Service_Fetch(request, reply), "handle") },
    // These never answered in MV2 either; the listener now says so (returns false) instead of holding the port (B50)
    OPEN_OPTIONS: { replies: false, handle: /* @__PURE__ */ __name(() => chrome.runtime.openOptionsPage(), "handle") },
    SEARCH_FOR: {
      replies: false,
      handle(request, reply, parsed, sender) {
        var _a;
        const { ITEM_ID, ITEM_TITLE, ITEM_TYPE, ID_PROVIDER, ITEM_YEAR, ITEM_URL, FILE_TYPE, FILE_PATH } = parsed;
        if (ITEM_TITLE && ITEM_TYPE)
          return ChangeStatus({ ITEM_ID, ITEM_TITLE, ITEM_TYPE, ID_PROVIDER, ITEM_YEAR, ITEM_URL, FILE_TYPE, FILE_PATH, TAB_ID: (_a = sender == null ? void 0 : sender.tab) == null ? void 0 : _a.id });
      }
    },
    SAVE_AS: { replies: false, handle: /* @__PURE__ */ __name((request, reply, parsed) => SaveAs(parsed), "handle") },
    DOWNLOAD_FILE: { replies: false, handle: /* @__PURE__ */ __name((request, reply, parsed) => DownloadFile(parsed), "handle") },
    UPDATE_CONFIGURATION: { replies: false, handle: /* @__PURE__ */ __name(() => RefreshTerminal(), "handle") },
    // utils.js: the page was left; its item no longer applies (F5)
    PAGE_HIDDEN: { replies: false, handle: /* @__PURE__ */ __name((request, reply, parsed, sender) => {
      var _a;
      return ForgetStatus((_a = sender == null ? void 0 : sender.tab) == null ? void 0 : _a.id);
    }, "handle") }
  };
  function Route(request, sender, sendResponse) {
    if ((sender == null ? void 0 : sender.id) !== chrome.runtime.id)
      return false;
    const route = ROUTES[request == null ? void 0 : request.type];
    if (!route)
      return false;
    Terminal().log("From:", sender);
    let replied = false;
    const reply = /* @__PURE__ */ __name((response) => {
      if (replied)
        return;
      replied = true;
      sendResponse(response);
    }, "reply");
    try {
      const result = route.handle(request, reply, ParseItem(request), sender);
      if (result instanceof Promise)
        result.catch((error) => {
          Terminal().error(error);
          route.replies && reply({ error: String(error), location: "@0B: Route => handler" });
        });
    } catch (error) {
      Terminal().error(error);
      reply({ error: String(error), location: "@0B: Route => handler" });
      return false;
    }
    return route.replies;
  }
  __name(Route, "Route");

  // src/background/plugins.js
  var PLUGINS = [
    { name: "foxsearchlight", file: "cloud/plugin/foxsearchlight.js", url: "*://*.foxsearchlight.com/(?!films|search|$)" },
    { name: "freemoviescinema", file: "cloud/plugin/freemoviescinema.js", url: "*://*.freemoviescinema.com/watch/*" },
    { name: "go", file: "cloud/plugin/go.js", url: "*://freeform.go.com/(movies|shows)/*" },
    {
      name: "indomovie",
      file: "cloud/plugin/indomovietv.js",
      url: "*://*.indomovietv.*/(?!tag|$)",
      // The options page's own list of its domains
      hosts: ["*.indomovietv.club", "*.indomovietv.org", "*.indomovietv.net"]
    },
    { name: "kitsu", file: "cloud/plugin/kitsu.js", url: "*://*.kitsu.io/anime/*" },
    { name: "myanimelist", file: "cloud/plugin/myanimelist.js", url: "*://*.myanimelist.net/anime/\\d+/*" },
    { name: "myshows", file: "cloud/plugin/myshows.js", url: "*://*.myshows.me/view/\\d+/*" },
    { name: "redbox", file: "cloud/plugin/redbox.js", url: "*://*.redbox.com/(ondemand-)?(movies|tvshows)/(?!featured|$)" },
    { name: "snagfilms", file: "cloud/plugin/snagfilms.js", url: "*://*.snagfilms.com/(films?|shows?)/*" },
    { name: "toloka", file: "cloud/plugin/toloka.js", url: "*://*.toloka.to/*" }
  ];
  var PLUGIN_CSS = ["sites/common.css", "sites/theme.css", "sites/glyphs.css", "sites/colors.css"];
  var PREFIX = "plugin-";
  function MatchesFor({ url, hosts }) {
    var _a;
    const host = hosts ?? [(_a = /^[^:]+:\/\/([^/]+)/.exec(url)) == null ? void 0 : _a[1]];
    return host.filter((name) => name && /^(\*\.)?[^*/]+$/.test(name)).map((name) => `*://${name}/*`);
  }
  __name(MatchesFor, "MatchesFor");
  function Registration(plugin) {
    return {
      id: PREFIX + plugin.name,
      matches: MatchesFor(plugin),
      js: ["utils.js", "helpers.js", "site-runner.js", plugin.file, `sites/plugin-boot/${plugin.name}.js`],
      css: PLUGIN_CSS,
      runAt: "document_idle"
    };
  }
  __name(Registration, "Registration");
  function TouchesPlugins(changes) {
    return Object.keys(changes).some((key) => /^plugin_/.test(key));
  }
  __name(TouchesPlugins, "TouchesPlugins");
  var SYNC_QUEUE = Promise.resolve();
  function SyncPlugins() {
    return SYNC_QUEUE = SYNC_QUEUE.then(Sync, Sync);
  }
  __name(SyncPlugins, "SyncPlugins");
  async function Sync() {
    const options = await GetOptions(), wanted = [];
    for (const plugin of PLUGINS) {
      const matches = MatchesFor(plugin);
      if (options[`plugin_${plugin.name}`] === true && matches.length && await chrome.permissions.contains({ origins: matches }))
        wanted.push(Registration(plugin));
    }
    const registered = (await chrome.scripting.getRegisteredContentScripts()).map((script) => script.id).filter((id) => id.startsWith(PREFIX));
    if (registered.length)
      await chrome.scripting.unregisterContentScripts({ ids: registered });
    if (wanted.length)
      await chrome.scripting.registerContentScripts(wanted);
    return wanted.map((script) => script.id);
  }
  __name(Sync, "Sync");

  // src/background/index.js
  chrome.runtime.onMessage.addListener(Route);
  chrome.runtime.onInstalled.addListener(() => (CreateMenus(), void SyncPlugins()));
  chrome.runtime.onStartup.addListener(() => void SyncPlugins());
  chrome.storage.onChanged.addListener((changes) => TouchesPlugins(changes) && void SyncPlugins());
  chrome.permissions.onAdded.addListener(() => void SyncPlugins());
  chrome.permissions.onRemoved.addListener(() => void SyncPlugins());
  chrome.contextMenus.onClicked.addListener((item) => void OnMenuClicked(item));
  chrome.tabs.onActivated.addListener(({ tabId }) => void SwitchStatus(tabId));
  chrome.storage.onChanged.addListener(() => void RefreshTerminal());
  RefreshTerminal();
  chrome.runtime.onInstalled.addListener((details) => void SeedDefaults(details));
})();
