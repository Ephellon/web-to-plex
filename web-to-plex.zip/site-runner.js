(() => {
  var __defProp = Object.defineProperty;
  var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

  // src/lib/site-runner.js
  var PUNCTUATION = [
    [/[‐-―]/g, "-"],
    // Hyphens and dashes
    [/[‚❟]/g, ","],
    // Low quotation commas
    [/[‘’‛❛❜]/g, "'"],
    // Single quotes and apostrophes
    [/[“-‟❝❞]/g, '"']
    // Double quotes
  ];
  var DEFAULT_TIMEOUT = 1e3;
  var NAVIGATION_EVENTS = ["popstate", "pushstate-changed"];
  var ACTIVE = /* @__PURE__ */ new WeakMap();
  var SHARED_ENVIRONMENT = null;
  function GlobToRegExp(url) {
    return RegExp(
      url.replace(/^\*:/, "\\w{3,}:").replace(/\*\./g, "(?:[^\\.]+\\.)?").replace(/\.\*/g, "(?:\\.[^\\/\\.]+)?").replace(/([/?&#])\*/g, "\\$1[^$]*"),
      "i"
    );
  }
  __name(GlobToRegExp, "GlobToRegExp");
  function ParseResultString(text) {
    const match = /^([^]+?)\s*\((\d{4})\):([\w-]+)$/.exec(text);
    if (match == null)
      return null;
    const [, title, year, type] = match;
    return { type, title, year };
  }
  __name(ParseResultString, "ParseResultString");
  function NormaliseItem(item) {
    let { type, title, year } = item;
    for (const [pattern, replacement] of PUNCTUATION)
      title = title.replace(pattern, replacement);
    year = +year;
    return { ...item, type, title, year };
  }
  __name(NormaliseItem, "NormaliseItem");
  function ClassifyResult(result, timeout = DEFAULT_TIMEOUT) {
    if (typeof result == "number") {
      if (result < 0)
        return { action: "no-render", data: result };
      return { action: "retry", delay: result || timeout };
    }
    if (!result)
      return { action: "retry", delay: timeout };
    if (typeof result == "string") {
      const permission = /^<([^<>]+)>$/.exec(result);
      if (permission)
        return { action: "stop", message: `The instance requires the "${permission[1]}" permission` };
      const parsed = ParseResultString(result);
      if (parsed == null)
        return { action: "stop", message: `Unrecognised result string "${result}"` };
      result = parsed;
    }
    if (typeof result != "object")
      return { action: "stop", message: `Unrecognised result type "${typeof result}"` };
    if (result instanceof Array) {
      const items = result.filter((item) => item);
      if (items.length > 1)
        return { action: "populate", data: items };
      if (items.length < 1)
        return { action: "stop", message: "Empty result list" };
      result = items[0];
    }
    if (typeof result.title != "string")
      return { action: "stop", message: "Result has no title" };
    return { action: "populate", data: NormaliseItem(result) };
  }
  __name(ClassifyResult, "ClassifyResult");
  function PathOf(href) {
    try {
      const { pathname, hash } = new URL(href);
      return /^#!?\//.test(hash) ? pathname + hash : pathname;
    } catch {
      return href;
    }
  }
  __name(PathOf, "PathOf");
  function RandomName(length = 16) {
    const values = [...crypto.getRandomValues(new Uint32Array(length))].map((value) => value.toString(36));
    return values.join("").replace(/^[^a-z]+/i, "");
  }
  __name(RandomName, "RandomName");
  function DefaultEnvironment() {
    const area = /* @__PURE__ */ __name(() => chrome.storage.sync ?? chrome.storage.local, "area");
    const get = /* @__PURE__ */ __name((key) => new Promise(
      (resolve) => area().get(key, (items) => resolve(chrome.runtime.lastError ? void 0 : items == null ? void 0 : items[key]))
    ), "get");
    return {
      href: /* @__PURE__ */ __name(() => location.href, "href"),
      get,
      // `~/cache/<name>` entries, saved as JSON by `plugn.js` `Save` and `helpers.js` `save`
      async getCache(name) {
        const value = await get("~/cache/" + name.toLowerCase().replace(/\s+/g, "_"));
        return value == null ? null : JSON.parse(value);
      },
      // utils.js sets `HandleInstanceMessage` once its options have loaded
      async populate(request) {
        for (let tries = 0; typeof HandleInstanceMessage != "function" && tries < 300; ++tries)
          await new Promise((resolve) => setTimeout(resolve, 100));
        if (typeof HandleInstanceMessage != "function")
          throw new Error(`utils.js never set HandleInstanceMessage; dropped ${request.type}`);
        return HandleInstanceMessage(request);
      },
      require: /* @__PURE__ */ __name((...args) => typeof Require == "function" ? Require(...args) : void 0, "require"),
      minionsWanted: /* @__PURE__ */ __name(() => get("UseMinions"), "minionsWanted"),
      listen(handler) {
        for (const type of NAVIGATION_EVENTS)
          top.addEventListener(type, handler);
        window.onlocationchange = handler;
      },
      setTimeout: /* @__PURE__ */ __name((callback, delay) => setTimeout(callback, delay), "setTimeout"),
      clearTimeout: /* @__PURE__ */ __name((timer) => clearTimeout(timer), "clearTimeout"),
      warn: /* @__PURE__ */ __name((...messages) => console.warn(...messages), "warn")
    };
  }
  __name(DefaultEnvironment, "DefaultEnvironment");
  function SharedEnvironment() {
    return SHARED_ENVIRONMENT ??= DefaultEnvironment();
  }
  __name(SharedEnvironment, "SharedEnvironment");
  async function RunSite(script, { alias, type = "script" } = {}, env = SharedEnvironment()) {
    const kind = type.toLowerCase(), TYPE = kind.toUpperCase(), instance = env.instance ?? RandomName(), timeout = script.timeout || DEFAULT_TIMEOUT;
    let timer = null, path = null;
    const request = /* @__PURE__ */ __name((requestType, data) => ({ data, instance, [kind]: alias, instance_type: TYPE, type: requestType }), "request");
    const schedule = /* @__PURE__ */ __name((delay) => {
      env.clearTimeout(timer);
      timer = env.setTimeout(() => run(), delay);
    }, "schedule");
    const run = /* @__PURE__ */ __name(async () => {
      env.clearTimeout(timer);
      path = PathOf(env.href());
      if (await env.get(`${kind == "plugin" ? "plugin" : "builtin"}_${alias}`) === false)
        return post({ action: "stop", message: 'The instance requires the "allowed" permission' });
      if (await env.getCache(`has/${alias}`) === false)
        return post({ action: "stop", message: 'The instance requires the "authorized" permission' });
      const pattern = GlobToRegExp(script.url);
      if (!pattern.test(env.href())) {
        env.warn(`The domain (${env.href()}) does not match the pattern '${script.url}' (${pattern})`);
        return post({ action: "no-render", data: -1 });
      }
      if (script.requires instanceof Array)
        await env.require(["cache", ...script.requires].join(","), alias, script.requiresName ?? alias, instance);
      if (!(script.init instanceof Function)) {
        env.warn(`The ${kind} (${alias}) is incorrectly structured. Could not find required function ${kind}.init`);
        return post({ action: "no-render", data: -1 });
      }
      let state = void 0, result;
      try {
        if (script.ready instanceof Function) {
          state = await script.ready();
          if (!state)
            return post({ action: "retry", delay: timeout });
        }
        if (await env.minionsWanted() && script.minions instanceof Function)
          script.minions();
        result = await (state === void 0 ? script.init() : script.init(state));
      } catch (error) {
        env.warn(`[${alias}] ${error}`);
        return post({ action: "retry", delay: timeout });
      }
      return post(ClassifyResult(result, timeout));
    }, "run");
    const post = /* @__PURE__ */ __name(async (outcome) => {
      switch (outcome.action) {
        case "populate":
          {
            await env.populate(request("POPULATE", outcome.data));
          }
          break;
        case "no-render":
          {
            await env.populate(request("NO_RENDER", outcome.data));
          }
          break;
        case "retry":
          {
            schedule(outcome.delay);
          }
          break;
        case "stop":
          {
            env.warn(`[${alias}] ${outcome.message}`);
          }
          break;
      }
      return outcome;
    }, "post");
    let sites = ACTIVE.get(env);
    if (sites == null)
      ACTIVE.set(env, sites = /* @__PURE__ */ new Map());
    const previous = sites.get(alias);
    previous == null ? void 0 : previous.stop();
    sites.set(alias, { rerun: /* @__PURE__ */ __name(() => schedule(0), "rerun"), stop: /* @__PURE__ */ __name(() => env.clearTimeout(timer), "stop"), path: /* @__PURE__ */ __name(() => path, "path") });
    if (previous == null)
      env.listen(() => {
        const site = sites.get(alias);
        if (PathOf(env.href()) != site.path())
          site.rerun();
      });
    return run();
  }
  __name(RunSite, "RunSite");

  // src/lib/site-runner-entry.js
  globalThis.RunSite = RunSite;
})();
