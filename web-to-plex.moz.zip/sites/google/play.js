/* global Update */ // Update(type:string, details:object)
(init = () => Update('SCRIPT', { script: 'google.play' }))();
